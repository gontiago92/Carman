/*let dropdowns = document.querySelectorAll('.dropdown')

dropdowns.forEach(element => {
  element.addEventListener('click', (e) => {

    e.preventDefault()
    e.stopPropagation()

    closeVisibleElements()

    let link = element.querySelector('a')
    let arrow = link.lastChild
    let dm = element.querySelector('.dropdown-menu')
    let height = element.clientHeight

    if(dm.dataset.hidden === "true") {
      element.style.height = height + dm.clientHeight + "px"
      dm.dataset.hidden = "false"

      link.classList.add('active')
      arrow.style.transform = 'rotate(90deg)'
    } else {
      element.style.height = height - dm.clientHeight + "px"
      dm.dataset.hidden = "true"

      link.classList.remove('active')
      arrow.style.transform = 'rotate(0deg)'  
    }
  })
})

document.addEventListener('click', function() {
    closeVisibleElements()
})

function closeVisibleElements() {
    let visibleElements = document.querySelectorAll('[data-hidden="false"]')

    for(let i = 0; i < visibleElements.length; i++) {
        let dropdown = visibleElements[i].parentNode
        let link = dropdown.querySelector('a')
        let arrow = link.lastChild
        let height = dropdown.clientHeight

        if(visibleElements[i].dataset.hidden === "false") {

        dropdown.style.height = height - visibleElements[i].clientHeight + "px"
        visibleElements[i].dataset.hidden = "true"

        link.classList.remove('active')
        arrow.style.transform = 'rotate(0deg)'  
        }
    }
}*/


/************************************* */


class Dropdown {
    static smoothClose(toggle, dropdownMenu) {
        console.log('Function CLOSE called !!')
        let link = toggle.querySelector('a')
        let arrow = link.lastChild
        let height = toggle.clientHeight


        toggle.style.height = height - dropdownMenu.clientHeight + "px"
        dropdownMenu.dataset.hidden = "true"

        link.classList.remove('active')
        arrow.style.transform = 'rotate(0deg)'
    }
    static smoothOpen(toggle, dropdownMenu) {
        console.log('Function OPEN called !!' + dropdownMenu.dataset.hidden)

        let link = toggle.querySelector('a')
        let arrow = link.lastChild
        let height = toggle.clientHeight

        toggle.style.height = height + dropdownMenu.clientHeight + "px"
        dropdownMenu.dataset.hidden = "false"

        link.classList.add('active')
        arrow.style.transform = 'rotate(90deg)'

    }
    static smoothToggle(toggle, dropdownMenu) {

        if(dropdownMenu.dataset.hidden === "true") { 
            this.closeVisibleElements()
            this.smoothOpen(toggle, dropdownMenu)
        } else {  
            this.smoothClose(toggle, dropdownMenu)
        }
    }

    static closeVisibleElements() {
        let visibleElements = document.querySelectorAll('[data-hidden="false"]')
        visibleElements.forEach(element => {
            console.log(element.parentNode)
            this.smoothClose(element.parentNode, element)
        })
    }
}

(function() {
  
  let dropdownMenuLink = document.querySelectorAll('.dropdown')

  dropdownMenuLink.forEach(element => {

    element.addEventListener('click', (e) => {
      e.preventDefault()
      e.stopPropagation()

      let dropdownMenu = element.querySelector('.dropdown-menu')

      Dropdown.smoothToggle(element, dropdownMenu)

    })
  }) 

document.addEventListener('click', element => {
    Dropdown.closeVisibleElements()
})


})()